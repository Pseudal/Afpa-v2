import React from 'react';

const Mention = () => {
    return (
        <div>
            
        </div>
    );
};

export default Mention;