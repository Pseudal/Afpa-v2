import React from "react";
import Logo from "../components/Logo";
import Navigation from "../components/Navigation";

const About = () => {
  return (
    <>
      <>
        <div>
            <Logo />
            <Navigation />
          <h1>A propo</h1>
        </div>
        <br />
      </>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique
        veritatis incidunt dignissimos magnam est et, sint voluptatem eius.
        Perspiciatis delectus eveniet velit, aliquam qui officia provident?
        Officia dolorum dolor est! Corrupti id accusamus ipsam, officia quas
        neque, accusantium optio facere commodi modi vitae. Recusandae, soluta.
        Temporibus veniam eius tempore tempora expedita, nulla debitis minima
        magni eos animi adipisci voluptatum illum itaque rem. Maiores error
        dignissimos accusamus aspernatur, eos aliquid, omnis iure magnam
        officiis reprehenderit fugiat possimus voluptate voluptatibus eum ipsam,
        consectetur culpa. Cumque assumenda ipsa corrupti, dolor quas, sit quam
        excepturi iste, tempore eius perspiciatis. Officia velit tempore aliquid
        consectetur.
      </p>
      <br />
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam quas
        blanditiis culpa id sit voluptatem voluptate dolorem corrupti neque
        laborum delectus, totam, voluptatibus quo dignissimos exercitationem
        vitae nesciunt perferendis modi.
      </p>
    </>
  );
};

export default About;
