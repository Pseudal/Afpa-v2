import React from "react";

const Error404 = () => {
  return (
    <div>
      <h1>Erreur 404</h1>
      <br />
      <p>Page introuvable</p>
    </div>
  );
};

export default Error404;
